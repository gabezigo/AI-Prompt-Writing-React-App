# AI Prompt Writing Generator

This is a sleek React app (Create React App compatible) styled in a Framer-like glassmorphism design. Ready to deploy to Netlify.

## How to deploy

1. Push the repository to GitHub.
2. Connect the repo to Netlify (Import from Git).
3. Set Build command to `npm run build` and Publish directory to `build`.
4. Trigger a deploy.

